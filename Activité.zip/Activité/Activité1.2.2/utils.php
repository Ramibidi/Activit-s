<?php function getArticles($nmbr_article){
 
 $articles = [
  
     [
  
         'titre' => 'Article 1',
  
         'texte' => 'Php',
  
         'auteur' => 'Rami',
  
         'date' => '03-05-2021',
  
         
  
     ],
  
     [
  
         'titre' => 'Article 2',
  
         'texte' => 'Wampserver',
  
         'auteur' => 'Semi',
  
         'date' => '19-02-2021',
  
     ],
  
     [
  
         'titre' => 'Article 3',
  
         'texte' => 'Java',
  
         'auteur' => 'Mourad',
  
         'date' => '15-08-2021',
  
     ],
  
 ];
  
 // foreach ($articles as $key=> $value)
 // {
 //     print_r($value);
 // }
  
 // Compare function
 function date_compare($element1, $element2) {
     $datetime1 = strtotime($element1['date']);
     $datetime2 = strtotime($element2['date']);
     return $datetime2 - $datetime1;
 }
     // Sort the array 
     $sort=usort($articles, 'date_compare');
  
 // Print the array
 //print_r($articles);
 
 
 
 
 
 
 
  
     if ($nmbr_article>0 && $nmbr_article<=3)
  
     {
           $sliced_array[] = array_slice($articles, 0, $nmbr_article);
           echo "few";
  
       return print_r($sliced_array);
  
     }
  
     else  {
         foreach ($articles as $value) {
  
             $newArray[] = $value;
     }
     print_r($newArray);
     echo "all";
 }
 }
 getArticles(3);
 ?>