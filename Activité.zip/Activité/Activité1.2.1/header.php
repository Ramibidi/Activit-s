         
        <h1>Mon premier site PHP</h1>
        <div style="background-color : green ;clear:both;">
            <ul style="display:flex; justify-content : space-evenly;">
                <li>Home</a></li>
                <li>Product</a></li>
                <li>Blog</a></li>
                <li>Contact</a></li>
            </ul>
        </div>
            
  