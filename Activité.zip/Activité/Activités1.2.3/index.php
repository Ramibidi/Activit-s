<html>
<head>
<?php
include ('header.php');

?>
<body>
C est un journal d information en ligne participatif, independant, sans publicite ni subvention et qui ne vit que des abonnements de ses lecteurs.
<br/>
<?php
include ('utils.php');
?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<?php
include ('footer.php');
?>

</body>
</html>
